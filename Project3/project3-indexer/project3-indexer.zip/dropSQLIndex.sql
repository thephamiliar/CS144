DROP INDEX sp_index ON SpatialTable;
DROP TABLE SpatialTable;