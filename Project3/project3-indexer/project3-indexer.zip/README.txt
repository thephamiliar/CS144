Our index is built just on ItemID, because ItemID is the primary key, thus just indexing the ItemID is enough to
organize the entire database.