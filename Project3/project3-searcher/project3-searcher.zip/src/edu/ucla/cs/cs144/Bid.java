package edu.ucla.cs.cs144;

import java.util.*;

public class Bid {

	public int rating;
	public String userId;
	public String location;
	public String country;
	public String time;
	public float amount;
}