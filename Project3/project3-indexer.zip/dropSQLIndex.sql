-- index is dropped when table is dropped
DROP TABLE IF EXISTS SpatialTable;